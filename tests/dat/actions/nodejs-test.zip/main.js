function main(args) {
  var ow = require('openwhisk');
  // actions only exists on 2.* versions of openwhisk, not 3.*
  var actions = ow().actions;

  return { "message": "success" };
}

exports.main = main;