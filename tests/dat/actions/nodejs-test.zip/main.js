function main(args) {
  let x = require('abcxyz')
  return { "message": x() };
}

module.exports = {
  main: main,
  niam: main
}
